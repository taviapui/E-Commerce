<!DOCTYPE html>
<html>
	<?php 
	   include 'header.php'; 
	?>
	
	<body>
		
	<div class="row">
		<div class="navbar-wrapper">
            <?php 
                include 'navigation.php';
            ?>
		</div>
	</div>

	<div class="container" style="font-family: Calibri Light;">
	  <div class="row">
	  <div class="col-lg-4 col-md-2 col-sm-2 col-xs-0"></div>
  	  <div class="col-lg-4 col-md-8 col-sm-8 col-xs-12">
  	  	<h2 style="text-align:center;"><b> - Our Mission - </b></h2>
  	  </div>
  	  <div class="col-lg-4 col-md-2 col-sm-2 col-xs-0"></div>
	  </div>
	  
	  <div class="row">
		<div class="col-lg-2 col-md-2 col-sm-2 col-xs-0">
		</div>
		<div class="col-lg-8 col-md-8 col-sm-8 col-xs-12">
			<h3 style="text-align:center; font-size: 22px;">To provide th most actionable app store data.</h3>
		</div>
		<div class="col-lg-2 col-md-2 col-sm-2 col-xs-0">
		</div>
	  </div>
	  
	  <div class="row">
	  <div class="col-lg-4 col-md-2 col-sm-2 col-xs-0"></div>
  	  <div class="col-lg-4 col-md-8 col-sm-8 col-xs-12">
  	  	<h2 style="text-align:center;"><b> About Us </b></h2>
  	  </div>
  	  <div class="col-lg-4 col-md-2 col-sm-2 col-xs-0"></div>
	  </div>
	  
	   <div class="row">
		<div class="col-lg-1 col-md-2 col-sm-2 col-xs-0">
		</div>
		<div class="col-lg-10 col-md-8 col-sm-8 col-xs-12">
			<h3 style="text-align:center; font-size: 22px">Our company name is W&G short form of want and get, our company is a jewerly shop. In our website and physical shop you will see a lot of jewerly like rings, bracelet, necklace and pendants.

			Our company is support hybird mode which are online shopping and come to our physical shop to watch the exactly products and buy it. In this 21 st century, online shopping become part of the shopping mode especially in this few year. </h3>
		</div>
		<div class="col-lg-1 col-md-2 col-sm-2 col-xs-0">
		</div>
	  </div>
	</div>
	
	<br><br><br><br><br><br><br>
	<?php 
    include "footer.php";
    ?>
	
	</body>
</html>

	
