<!DOCTYPE html>
<html>
    <?php 
       include 'header.php';
    ?>

<body>
            
<!-- navigation bar -->       
    <div class="row" style="margin-bottom: 10%;">
        <div class="navbar-wrapper" style="position: fixed; min-width: 102%; z-index: 9999;">
          <?php 
            include 'navigation.php';
          ?>
        </div>
    </div>
<!-- /navigation bar -->    

        <div class="container itemList">
            <div class="row">
                <div class="col-lg-3 col-md-3 col-sm-3 col-xs-0"></div>
                <div class="col-lg-6 col-md-6 col-sm-6 col-xs-12">
                    <h2 class="log-in-title">Log In for Admin</h2>
                </div>      
                <div class="col-lg-3 col-md-3 col-sm-3 col-xs-0"></div>
            </div>  
            <div class="row">    
                <div class="col-lg-3 col-md-3 col-sm-3 col-xs-0"></div>
                <div class="col-lg-6 col-md-6 col-sm-6 col-xs-12">
                    <form action="AdminSignedin.php" method="POST">
                        <div class="form-group">

                            <label for="adminName"><b>Admin Name</b></label>
                            <input type="text" class="form-control"placeholder="Enter Name" name="adminName">
                        </div>

                        <div class="form-group">
                            <label for="pass"><b>Password</b></label>
                            <input type="password"class="form-control" placeholder="Enter Password" name="pass">
                        </div> 

                        <input class="signin_button" type="submit" value="SIGN IN">
                    </form>
                    <?php
                        if (isset($_GET["error"])) {
                            if ($_GET["error"] == "empty_signin") {
                                echo "<span style='color: red'>Please fill in all the fields.</span>";
                            }
                            else if ($_GET["error"] == "login_error") {
                                echo "<span style='color: red'>Incorrect name or password, please try again.</span>";
                            }
                        }
                    ?>
                        
                        <div class="etc-login-form">
                            <p>If you can't login contact Adminstration</p>
                        </div>
                        <div class="col-lg-3 col-md-3 col-sm-3 col-xs-0"></div>
                        </div>

            </div>
        </div>
<!-- Footer -->
    <?php 
       include 'footer.php';
    ?>
<!-- Footer -->
        
</body>
</html>