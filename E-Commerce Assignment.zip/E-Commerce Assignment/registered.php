<?php

require_once 'dbconnect.php';
require_once 'function.php';


if (isset($_POST["username"]) && isset($_POST["email"]) && isset($_POST["contactNumber"]) && isset($_POST["age"]) && isset($_POST["pass"]) && isset($_POST["confPass"])) {
    
    $username = validate($_POST['username']);
    $email = validate($_POST['email']);
    $contactNumber = validate($_POST['contactNumber']);
    $age = validate($_POST['age']);
    $pass = validate($_POST['pass']);
    $confPass = validate($_POST['confPass']);

    if (empty_input($username, $email, $contactNumber, $age, $pass, $confPass) !== false) {
        header("location: register.php?error=empty_input");
        exit();
    }

    if (error_username($username) !== false) {
        header("location: register.php?error=error_username");
        exit();
    }

    if (error_email($email) !== false) {
        header("location: register.php?error=error_email");
        exit();
    }

    if (error_contactNumber($contactNumber) !== false) {
        header("location: register.php?error=error_contactNumber");
        exit();
    }

    if (error_age($age) !== false) {
        header("location: register.php?error=error_age");
        exit();
    }

    if (longer_password($pass) !== false) {
        header("location: register.php?error=passwordtooshort");
        exit();
    }
    
    if (password_match($pass, $confPass) !== false) {
        header("location: register.php?error=passwordnotmatch");
        exit();
    }

    if (username_exists($conn, $username) !== false) {
        header("location: register.php?error=username_taken");
        exit();
    }

    if (email_exists($conn, $email) !== false) {
        header("location: register.php?error=email_taken");
        exit();
    }

    register_user($conn, $username, $email, $contactNumber, $age, $pass);
}

else{
    header("location: register.php");
    exit();
}
