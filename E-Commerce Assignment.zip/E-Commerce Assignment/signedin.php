<?php

require_once 'dbconnect.php';
require_once 'function.php';

if (isset($_POST["username"]) && isset($_POST["pass"])) {

    $username = validate($_POST['username']);
    $pass = validate($_POST['pass']);

    if (empty_signin($username, $pass) !== false) {
        header("location: signin.php?error=empty_signin");
        exit();
    }
        
    signin_user($conn, $username, $pass);

}
else{
    header("location: signin.php");
    exit();
}

?>