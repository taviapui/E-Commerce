<?php

require_once 'dbconnect.php';
require_once 'paymentFunction.php';


if (isset($_POST["username"]) && isset($_POST["cardHolderName"]) && isset($_POST["cardNumber"]) && isset($_POST["cvc"]) && isset($_POST["expiration"])) {
    
    $username = validate($_POST['username']);
    // $amount = validate($_POST['amount']);
    $cardHolderName = validate($_POST['cardHolderName']);
    $cardNumber = validate($_POST['cardNumber']);
    $cvc = validate($_POST['cvc']);
    $expiration = validate($_POST['expiration']);

    if (empty_input($username, $cardHolderName, $cardNumber, $cvc, $expiration) !== false) {
        header("location: payment.php?error=empty_input");
        exit();
    }

    if (error_username($username) !== false) {
        header("location: payment.php?error=error_username");
        exit();
    }

    // if (error_amount($amount) !== false) {
    //     header("location: payment.php?error=error_amount");
    //     exit();
    // }

    if (error_cardHolderName($cardHolderName) !== false) {
        header("location: payment.php?error=error_cardHolderName");
        exit();
    }

    if (error_cardNumber($cardNumber) !== false) {
        header("location: payment.php?error=error_cardNumber");
        exit();
    }


    if (error_cvc($cvc) !== false) {
        header("location: payment.php?error=error_cvc");
        exit();
    }

    if (error_expiration($expiration) !== false) {
        header("location: payment.php?error=error_expiration");
        exit();
    }
    

    payment_user($conn, $username, $cardHolderName, $cardNumber, $cvc, $expiration);
}

else{
    header("location: payment.php");
    exit();
}
