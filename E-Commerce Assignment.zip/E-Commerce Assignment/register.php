<!DOCTYPE html>
<html>
    <?php 
       include 'header.php';
    ?>

   <body>

    <!-- navigation bar -->       
    <div class="row" style="margin-bottom: 10%;">
        <div class="navbar-wrapper" style="position: fixed; min-width: 102%; z-index: 9999;">
          <?php 
            include 'navigation.php';
          ?>
        </div>
    </div>
<!-- /navigation bar --> 

      <div class="container itemList">
          <div class="row">
              <div class="col-lg-3 col-md-2 col-sm-2 col-xs-0"></div>
              <div class="col-lg-6 col-md-8 col-sm-8 col-xs-12">
                <h2>User Registration Form</h2>
              </div>
            <div class="col-lg-3 col-md-2 col-sm-2 col-xs-0"></div>
          </div>
            <div class="row">
                <div class="col-lg-3 col-md-2 col-sm-2 col-xs-0">
            </div>
        <div class="col-lg-6 col-md-8 col-sm-8 col-xs-12">
         <form action="registered.php" method="POST">    
        
            
            <div class="form-group">
                <label for="username"><b>Username</b></label>
                <input type="text" class="form-control" placeholder="Enter Username" name="username">
            </div>
            
            <div class="form-group">
                <label for="email"><b>Email</b></label>
                <input type="text" class="form-control" placeholder="Enter Email" name="email">
            </div>
            
            <div class="form-group">
                <label for="contactNumber"><b>Contact Number</b></label>
                <input type="text" class="form-control" placeholder="Enter Contact Number" name="contactNumber">
            </div>

            <div class="form-group">
                 <label for="age"><b>Age</b></label>
                <input type="text" class="form-control" placeholder="Enter Age" name="age">
            </div> 




            <div class="form-group">
                <label for="pass"><b>Password</b></label>
                <input type="password" class="form-control" placeholder="Enter Password" name="pass">
            </div>  
            
            <div class="form-group">
                <label for="confPass"><b>Repeat Password</b></label>
                <input type="password" class="form-control" placeholder="Repeat Password" name="confPass">
            </div>
              
            
            <input class="register_button" type="submit" value="SIGN UP">
            
            <div class="etc-login-form">
                <p>Already have an account? <a href="signin.php">Login Here</a></p>
            </div>
        </form>

        <?php
            if (isset($_GET["error"])) {
                if ($_GET["error"] == "empty_input") {
                    echo "<span style='color: red'>Please fill in all the fields.</span>";
                }
                else if ($_GET["error"] == "error_username") {
                    echo "<span style='color: red'>Please enter a another username.</span>";
                }
                else if ($_GET["error"] == "error_email") {
                    echo "<span style='color: red'>Please enter a valid email.</span>";
                }
                else if ($_GET["error"] == "error_contactNumber") {
                    echo "<span style='color: red'>Please enter a valid contact number.</span>";
                }
                else if ($_GET["error"] == "error_age") {
                    echo "<span style='color: red'>Please enter a valid age.</span>";
                }
                else if ($_GET["error"] == "passwordtooshort") {
                    echo "<span style='color: red'>Your password is too short.</span>";
                }
                else if ($_GET["error"] == "passwordnotmatch") {
                    echo "<span style='color: red'>Your password does not match.</span>";
                }
                else if ($_GET["error"] == "username_taken") {
                    echo "<span style='color: red'>Your username has been taken, please try again.</span>";
                }
                else if ($_GET["error"] == "email_taken") {
                    echo "<span style='color: red'>Your email has been taken, please try again.</span>";
                }
                else if ($_GET["error"] == "register_succeeded") {
                    echo "<span style='color: red'>Your account has been registered successfully.</span>";
                }
                else if ($_GET["error"] == "register_failed") {
                    echo "<pspan style='color: red'>Something is wrong, please try again.</span>";
                }
            }
            ?>
        </div>
        <div class="col-lg-3 col-md-2 col-sm-2 col-xs-0">
        </div>
      </div>
    </div>
        </div> 

         <!-- <input class="register_button" type="submit" value="SIGN UP"> -->

           
        
    </body>
</html>