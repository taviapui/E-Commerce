<?php
session_start();
include 'function.php';

if (isset($_SESSION["username"])) {
    $username = validate($_SESSION["username"]);
    
    destroy_session_and_data();
    header("location: logoutSuccesful.php");
    exit();
}

?>