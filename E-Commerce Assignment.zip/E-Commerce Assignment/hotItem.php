  <!-- content start -->
  <div id="hotItem">
      <div class="container">
        <div class="item" style="text-align: center; background-color: burlywood;">
            <h1>Hot Items</h1>
          </div>
        <div class="row flex">
          <div>
            <div class="col-lg-4 col-sm-6">
            <div class="thumbnail">
              <img src="image/Ring/R_img3(handcuff_titanium).jpg" style="width: 225px; height: 225px;">
            </div>
            <span>Titanium resizeable Handcuff Ring</span><br/>
            <a id="cart" type="button" href="ring.php">Shop More</a>
            </div>
            
            <div class="col-lg-4 col-sm-6">
              <div class="thumbnail">
                <img src="image/Bracelet/B_img2(key_Rose).jpg" style="width: 225px; height: 225px;">
              </div>
              <span>Rose Gold Key Bracelet</span><br/>
              <a id="cart" type="button" href="bracelet.php">Shop More</a>
            </div>

            <div class="col-lg-4 col-sm-6">
              <div class="thumbnail">
                <img src="image/pendants/Pg_img7(IranMap).jpg" style="width: 225px; height: 225px;">
              </div>
              <span>Sliver Iran Map Pendants</span><br/>
              <a id="cart" type="button" class="cart" href="pendant.php">Shop More</a>
            </div>

            
            
          </div>

        </div>

      </div>
  </div>



