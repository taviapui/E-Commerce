<nav class="navbar navbar navbar-default navbar-static-top">        
    <div class="container-fluid">
        <div id="navbar" class="navbar-collapse collapse">
            <a href="index.php">
                <img class="school-logo-size" src="image/Logo.jpg" alt="W & G" style="height: 80px; width: 210px;">
            </a>
            <div class="w3-show-inline-block" style="float: right; margin-right: 2%;">
              <div class="dropdown">
                <button class="btn btn-default">Log In</button>
                <div class="dropdown-content">
                    <a href="signin.php">User</a>
                    <a href="AdminSignin.php">Admin</a>
                </div>
              </div>
                <button id="registration" type="button" class="btn btn-default"><a style="color: black;" href="register.php">Register</a></button>
              </div>
            </div>
        </div>   

        <!-- Navigation Bar -->
        <div>
            <ul class="nav navbar-nav" style="float:left;  padding-top:0px; padding-right: 35px; padding-left: 2%; min-width: 100%; background-color: beige;">                       
                <li>
                    <a href="index.php" target="_self">HOME</a> 
                </li>
                
                <li class="dropdown"> <a class="dropdown" aria-expanded="false" contenteditable="false"
                    href="#" data-toggle="dropdown" >Categories of Product<span class="caret"></span> </a>
                    <ul class="dropdown-content">
                        <a href="gallery.php">All Products</a>
                        <a href="bracelet.php">Bracelets</a>
                        <a href="ring.php">Rings</a>
                        <a href="necklace.php">Necklaces</a>
                        <a href="pendant.php">Pendants</a>
                    </ul>
                </li>

                <li>
                    <a href="search.php" target="_self">Fast Searching</a>
                <li>

                <li>
                    <a href="AboutUs.php" target="_self">About Us</a>
                <li>
                    
                <li>
                    <a href="shopLocation.php" target="_self">Physical Shop Location</a>
                </li>

                <li style="float: right;">
                    <a href="logout.php" target="_self">Logout</a>
                </li>
                <!-- <li class="dropdown"> <a class="dropdown-toggle" aria-expanded="false" contenteditable="false"
                    href="#" data-toggle="dropdown" ><span class="glyphicon glyphicon-user"></span></a>
                       
                </li> -->
            </ul> 
        </div>
    </div>
</nav>

