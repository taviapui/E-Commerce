<?php
session_start();
require_once("dbcontroller.php");
include 'header.php';

$db_handle = new DBController();
//Get method for adding/remove item to Cart
if(!empty($_GET["action"])) {
switch($_GET["action"]) {
	
	case "remove":
		if(!empty($_SESSION["cart_item"])) {
			foreach($_SESSION["cart_item"] as $k => $v) {
					if($_GET["code"] == $k)
						unset($_SESSION["cart_item"][$k]);
                                        // if no more item in cart, empty the session
					if(empty($_SESSION["cart_item"]))
						unset($_SESSION["cart_item"]);
			}
		}
	break;
	case "empty":
		unset($_SESSION["cart_item"]);
	break;	
}
}
?>
<HTML>
<?php 
	   include 'header.php'; 
	?>
	
	<body>
		
	<div class="row">
		<div class="navbar-wrapper">
            <?php 
                include 'navigation.php';
            ?>
		</div>
	</div>
<BODY>
<div id="shopping-cart">
<div class="txt-heading">Shopping Cart</div>
	<div style="margin-bottom: 5%;">
		<a id="btnEmpty" class="btn btn-danger" href="Cart.php?action=empty">Empty Cart</a>
	</div>
<?php
if(isset($_SESSION["cart_item"])){
    $total_quantity = 0;
    $total_price = 0;
?>
<!-- This table is the shopping cart.  -->	
<table class="tbl-cart" cellpadding="10" cellspacing="1">
<tbody>
<tr>
<th style="text-align:left;">Name</th>
<th style="text-align:left;">Code</th>
<th style="text-align:right;" width="5%">Quantity</th>
<th style="text-align:right;" width="10%">Unit Price</th>
<th style="text-align:right;" width="10%">Price</th>
<th style="text-align:center;" width="5%">Remove</th>
</tr>	
<?php		
    foreach ($_SESSION["cart_item"] as $item){
        $item_price = $item["quantity"]*$item["price"];
		?>
				<tr>
				<td><img src="<?php echo $item["image"]; ?>" class="cart-item-image"  style="width:90px; height:90px;"/><?php echo $item["name"]; ?></td>
				<td><?php echo $item["code"]; ?></td>
				<td style="text-align:right;"><?php echo $item["quantity"]; ?></td>
				<td  style="text-align:right;"><?php echo "$ ".$item["price"]; ?></td>
				<td  style="text-align:right;"><?php echo "$ ". number_format($item_price,2); ?></td>
				<td style="text-align:center;">
                                <!-- Get method to remove item in Cart -->
                                <a href="Cart.php?action=remove&code=<?php echo $item["code"]; ?>" class="btnRemoveAction">
                                <img src="image/icon-delete.png" alt="Remove Item" /></a></td>
				</tr>
				<?php
				$total_quantity += $item["quantity"];
				$total_price += ($item["price"]*$item["quantity"]);
		}
		?>

<tr>
<td colspan="2" align="right">Total:</td>
<td align="right"><?php echo $total_quantity; ?></td>
<td align="right" colspan="2"><strong><?php echo "$ ".number_format($total_price, 2); ?></strong></td>
<td></td>
</tr>
</tbody>
</table>	

<button class="btn btn-info" onclick=" window.open('payment.php','_blank')" style="float: right; margin-top:3%;">purchase</button>



  <?php
} else {
?>
<!-- When cart is empty  -->
<div class="no-records">Your Cart is Empty</div>
<?php 
}
?>
</div>
</HTML>
<?php 
    include "footer.php";
    ?>

