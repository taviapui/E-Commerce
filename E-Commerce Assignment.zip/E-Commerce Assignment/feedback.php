<!DOCTYPE html>
<html>
<head>
<style>

/* Button used to open the contact form - fixed at the bottom of the page */
.open-button {
  background-color: transparent;
  color: white;
  /*padding: 16px 20px;*/
  border: none;
  cursor: pointer;
  opacity: 0.8;
  position: fixed;
  bottom: 23px;
  right: -80px;
  width: 280px;
}

/* The popup form - hidden by default */
.form-popup {
  display: none;
  position: fixed;
  bottom: 0;
  right: 15px;
  border: 3px solid #f1f1f1;
  z-index: 9;
}

/* Add styles to the form container */
.form-container {
  max-width: 300px;
  padding: 10px;
  background-color: white;
}

/* Full-width input fields */
.form-container input[type=text], .form-container input[type=password] {
  width: 100%;
  padding: 15px;
  margin: 5px 0 22px 0;
  border: none;
  background: #f1f1f1;
}

/* When the inputs get focus, do something */
.form-container input[type=text]:focus, .form-container input[type=password]:focus {
  background-color: #ddd;
  outline: none;
}

/* Set a style for the submit/login button */
.form-container .btn {
  background-color: #04AA6D;
  color: white;
  padding: 16px 20px;
  border: none;
  cursor: pointer;
  width: 100%;
  margin-bottom:10px;
  opacity: 0.8;
}

/* Add a red background color to the cancel button */
.form-container .cancel {
  background-color: red;
}

/* Add some hover effects to buttons */
.form-container .btn:hover, .open-button:hover {
  opacity: 1;
}


input[type=text], select, textarea {
  width: 100%;
  padding: 12px;
  border: 1px solid #ccc;
  border-radius: 4px;
  box-sizing: border-box;
  margin-top: 6px;
  margin-bottom: 16px;
  resize: vertical;
}


</style>
</head>

<body>

<button class="open-button" onclick="openForm()"><img src="image/feedback.jpg" style="width: 50px; height: 50px;"></button>

<div class="form-popup" id="myForm">
  <form action="SubmitFeedback.php" class="form-container" method="POST">
    <h3>Contact Form</h3>


    <label for="username"><b>Username</b></label>
    <input type="text" id="username" name="username" placeholder="Please Enter Your Name..">

    <label for="email"><b>Email</b></label>
    <input type="text" id="email" name="email" placeholder="Please Enter Your Email Address..">

    <label for="comment"><b>Suggection</b></label>
    <textarea id="comment" name="comment" placeholder="Write something.." style="height:100px"></textarea>

    <!-- <button type="submit" class="btn">Submit</button> -->
    <button class="btn" type="submit">Submit</button>

    <button type="button" class="btn cancel" onclick="closeForm()">Close</button>
  </form>
  <?php
            if (isset($_GET["error"])) {
                if ($_GET["error"] == "empty_input") {
                    echo "<span style='color: red'>Please fill in all the fields.</span>";
                }
                else if ($_GET["error"] == "error_username") {
                    echo "<span style='color: red'>Please enter a another username.</span>";
                }
                else if ($_GET["error"] == "error_email") {
                    echo "<span style='color: red'>Please enter a valid email.</span>";
                }
                else if ($_GET["error"] == "error_comment") {
                    echo "<span style='color: red'>Your suggetion invalid.</span>";
                }
                else if ($_GET["error"] == "submit_succeeded") {
                    echo "<span style='color: red'>Your account has been registered successfully.</span>";
                }
                else if ($_GET["error"] == "feedback_failed") {
                    echo "<pspan style='color: red'>Something is wrong, please try again.</span>";
                }
            }
            ?>
</div>

<script>
function openForm() {
  document.getElementById("myForm").style.display = "block";
}

function closeForm() {
  document.getElementById("myForm").style.display = "none";
}
</script>

</body>
</html>
