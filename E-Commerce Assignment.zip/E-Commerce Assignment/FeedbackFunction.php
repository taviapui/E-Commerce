<?php

function validate($data) {
    $data = trim($data);
    $data = stripslashes($data);
    $data = htmlspecialchars($data);
    return $data;
}

function empty_input($username, $email, $comment) {
    $result;
    if(empty($username) || empty($email) || empty($comment)) {
        $result = true;
    }
    else{
        $result = false;
    }
    return $result;
}

function error_username($username) {
    $result;
    if(!preg_match('/^[a-zA-Z0-9]*$/', $username)) {
        $result = true;
    }
    else{
        $result = false;
    }
    return $result;
}

function error_email($email) {
    $result;
    if(filter_var($email, FILTER_VALIDATE_EMAIL)) {
        $result = false;
    }
    else{
        $result = true;
    }
    return $result;
}

function error_comment($comment) {
    $result;
    if(!preg_match('/^[a-zA-Z0-9 ]*$/', $comment)) {
        $result = true;
    }
    else{
        $result = false;
    }
    return $result;
}


function feedback_user($conn, $username, $email, $comment) {
    $sql = "INSERT INTO tblContact (username, email, comment) VALUES ('$username', '$email', '$comment');";
    $result = mysqli_query($conn, $sql);
    if ($result) {
        header("location: index.php?error=feedback_succeeded");
        exit();
    }
    else {
        header("location: index.php?error=feedback_failed");
        exit();
    }

}



function destroy_session_and_data() {
    unset($_SESSION["username"]);
    $_SESSION = array();
    session_unset();
    setcookie(session_name(), '', time() - 2592000, '/');
    session_destroy();
}

?>