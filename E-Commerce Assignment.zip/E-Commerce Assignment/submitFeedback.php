<?php

require_once 'dbconnect.php';
require_once 'FeedbackFunction.php';

if (isset($_POST["username"]) && isset($_POST["email"]) && isset($_POST["comment"])) {
    
    $username = validate($_POST['username']);
    $email = validate($_POST['email']);
    $comment = validate($_POST['comment']);

    if (empty_input($username, $email, $comment) !== false) {
        header("location: index.php?error=empty_input");
        exit();
    }

    if (error_username($username) !== false) {
        header("location: index.php?error=error_username");
        exit();
    }

    if (error_email($email) !== false) {
        header("location: index.php?error=error_email");
        exit();
    }

    if (error_comment($comment) !== false) {
        header("location: index.php?error=error_comment");
        exit();
    }

    feedback_user($conn, $username, $email, $comment);
}

else{
    header("location: feedback.php");
    exit();
}
