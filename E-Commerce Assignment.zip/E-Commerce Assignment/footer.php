<div class="container-fluid" style=" margin-top: 5%; min-width: 100%;">
	<div class="row">
        <p class="txt-railway footer-copyright" style="text-align:center; "><b>&copy; W & G 2021</b></p>
    </div>
</div>