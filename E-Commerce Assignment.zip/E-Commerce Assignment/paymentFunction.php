<?php

function validate($data) {
    $data = trim($data);
    $data = stripslashes($data);
    $data = htmlspecialchars($data);
    return $data;
}

function empty_input($username, $cardHolderName, $cardNumber, $cvc, $expiration) {
    $result;
    if(empty($username) || empty($cardHolderName) || empty($cardNumber)  || empty($cvc) ||  empty($expiration)) {
        $result = true;
    }
    else{
        $result = false;
    }
    return $result;
}

function error_username($username) {
    $result;
    if(!preg_match('/^[a-zA-Z0-9]*$/', $username)) {
        $result = true;
    }
    else{
        $result = false;
    }
    return $result;
}

// function error_amount($amount) {
//     $result;
//     if(!preg_match('/^\d{3}$/', $amount)) {
//         $result = false;
//     }
//     else{
//         $result = true;
//     }
//     return $result;
// }

function error_cardHolderName($cardHolderName) {
    $result;
    if(!preg_match('/^[a-zA-Z]*$/', $cardHolderName)) {
        $result = true;
    }
    else{
        $result = false;
    }
    return $result;
}

function error_cardNumber($cardNumber) {
    $result;
    if(!preg_match('/^\d{4}\-\d{4}\-\d{4}\-\d{4}$/', $cardNumber)) {
        $result = true;
    }
    else{
        $result = false;
    }
    return $result;
}

function error_cvc($cvc) {
    $result;
    if(!preg_match('/^\d{3}$/', $cvc)) {
        $result = true;
    }
    else{
        $result = false;
    }
    return $result;
}

function error_expiration($expiration) {
    $result;
    if(!preg_match('/^\d{2}\-\d{4}$/', $expiration)) {
        $result = true;
    }
    else{
        $result = false;
    }
    return $result;
}



function payment_user($conn, $username, $cardHolderName, $cardNumber, $cvc, $expiration) {
    $sql = "INSERT INTO payment (username, cardHolderName, cardNumber, cvc, expiration) VALUES ('$username', '$cardHolderName', '$cardNumber', '$cvc'. '$expiration');";
    $result = mysqli_query($conn, $sql);
    if ($result) {
        header("location: payment.php?error=payment_succeeded");
        exit();
    }
    else {
        header("location: payment.php?error=payment_failed");
        exit();
    }

}


function destroy_session_and_data() {
    unset($_SESSION["username"]);
    $_SESSION = array();
    session_unset();
    setcookie(session_name(), '', time() - 2592000, '/');
    session_destroy();
}

?>