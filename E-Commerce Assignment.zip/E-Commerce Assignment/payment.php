<!DOCTYPE html>
<html>
    <?php 
       include 'header.php';
    ?>

   <body>

    <!-- navigation bar -->       
    <div class="row" style="margin-bottom: 10%;">
        <div class="navbar-wrapper" style="position: fixed; min-width: 102%; z-index: 9999;">
          <?php 
            include 'navigation.php';
          ?>
        </div>
    </div>
<!-- /navigation bar --> 

      <div class="container itemList">
          <div class="row">
              <div class="col-lg-3 col-md-2 col-sm-2 col-xs-0"></div>
              <div class="col-lg-6 col-md-8 col-sm-8 col-xs-12">
                <h2>User Payment Form</h2>
              </div>
            <div class="col-lg-3 col-md-2 col-sm-2 col-xs-0"></div>
          </div>
            <div class="row">
                <div class="col-lg-3 col-md-2 col-sm-2 col-xs-0">
            </div>
        <div class="col-lg-6 col-md-8 col-sm-8 col-xs-12">
         <form action="paid.php" method="POST">    
        
            
            <div class="form-group">
                <label for="username"><b>Username</b></label>
                <input type="text" class="form-control" placeholder="Enter Username" name="username">
            </div>
            
           <!--  <div class="form-group">
                <label for="amount"><b>Amount</b></label>
                <input type="text" class="form-control" placeholder="Enter Amount" name="amount">
            </div> -->
            
            <div class="form-group">
                <label for="cardHolderName"><b>Card Holder Name</b></label>
                <input type="text" class="form-control" placeholder="Enter card Holder Name" name="cardHolderName">
            </div>

            <div class="form-group">
                 <label for="cardNumber"><b>Card Number</b></label>
                <input type="text" class="form-control" placeholder="0000-1111-2222-3333" name="cardNumber">
            </div> 

            <div class="form-group">
                <label for="cvc"><b>CVC</b></label>
                <input type="text" class="form-control" placeholder="311" name="cvc">
            </div>  
            
            <div class="form-group">
                <label for="expiration"><b>Expiration</b></label>
                <input type="text" class="form-control" placeholder="MM-YYYY" name="expiration">
            </div>
              
            
            <input class="payment_button" type="submit" value="Deal">
            
        </form>

        <?php
            if (isset($_GET["error"])) {
                if ($_GET["error"] == "empty_input") {
                    echo "<span style='color: red'>Please fill in all the fields.</span>";
                }
                else if ($_GET["error"] == "error_username") {
                    echo "<span style='color: red'>Please enter a another username.</span>";
                }
             
                else if ($_GET["error"] == "error_cardHolderName") {
                    echo "<span style='color: red'>Please enter a card Holder Name.</span>";
                }
                else if ($_GET["error"] == "error_cardNumber") {
                    echo "<span style='color: red'>Please enter a valid cardNumber.</span>";
                }
                else if ($_GET["error"] == "error_cvc") {
                    echo "<span style='color: red'>Please enter a valid cvc.</span>";
                }
                else if ($_GET["error"] == "error_expiration") {
                    echo "<span style='color: red'>Please enter a valid expiration.</span>";
                }
                
                else if ($_GET["error"] == "payment_succeeded") {
                    echo "<span style='color: red'>Your account has been registered successfully.</span>";
                }
                else if ($_GET["error"] == "payment_failed") {
                    echo "<pspan style='color: red'>Something is wrong, please try again.</span>";
                }
            }
            ?>
        </div>
        <div class="col-lg-3 col-md-2 col-sm-2 col-xs-0">
        </div>
      </div>
    </div>
        </div> 

         <?php 
    include "footer.php";
    ?>

           
        
    </body>
</html>