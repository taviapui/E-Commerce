<?php

$servername = "localhost";
$dbusername = "pei";
$dbpassword = "mypasswd";
$dbname = "wandg";



$conn = mysqli_connect($servername, $dbusername, $dbpassword, $dbname);

if (!$conn) {
  die("Connection failed: " . mysqli_connect_error());
}
?>