<?php

//fetch.php

$connect = new PDO("mysql:host=localhost;dbname=wandg", "pei", "mypasswd");

$output = '';

$query = '';

if(isset($_POST["query"]))
{
 $search = str_replace(",", "|", $_POST["query"]);
 $query = "
 SELECT * FROM tblproduct 
 WHERE name REGEXP '".$search."' 
 OR code REGEXP '".$search."' 
 OR price REGEXP '".$search."'
 ";
}
else
{
 $query = "
 SELECT * FROM tblproduct ORDER BY id
 ";
}

$statement = $connect->prepare($query);
$statement->execute();

while($row = $statement->fetch(PDO::FETCH_ASSOC))
{
 $data[] = $row;
}

echo json_encode($data);

?>
