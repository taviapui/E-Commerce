<?php

function validate($data) {
    $data = trim($data);
    $data = stripslashes($data);
    $data = htmlspecialchars($data);
    return $data;
}

function empty_signin($adminName, $pass) {
    $result;
    if(empty($adminName) || empty($pass)) {
        $result = true;
    }
    else{
        $result = false;
    }
    return $result;
}

function signin_admin($conn, $adminName, $pass) {
    $pass = validate($pass);
    //$pass = password_hash($pass, PASSWORD_DEFAULT);
    $sql = "SELECT * FROM admin WHERE adminName = '$adminName';";
    $result = mysqli_query($conn, $sql);
    if(mysqli_num_rows($result) === 1) {
        $row = mysqli_fetch_assoc($result);
        if ($row["adminName"] === $adminName && password_verify($pass, $row["pass"])) {
            session_start();
            $_SESSION["adminName"] = $row["adminName"];
            header("location: home.php");
            exit();
        }
        else {
            header("location: AdminSignin.php?error=login_error");
            exit();
        }
    }
    else {
        header("location: AdminSignin.php?error=login_error");
        exit();
    }
}

function destroy_session_and_data() {
    unset($_SESSION["adminName"]);
    $_SESSION = array();
    session_unset();
    setcookie(session_name(), '', time() - 2592000, '/');
    session_destroy();
}

?>