<?php

require_once 'dbconnect.php';
require_once 'AdminFunction.php';

if (isset($_POST["adminName"]) && isset($_POST["pass"])) {

    $adminName = validate($_POST['adminName']);
    $pass = validate($_POST['pass']);

    if (empty_signin($adminName, $pass) !== false) {
        header("location: AdminSignin.php?error=empty_signin");
        exit();
    }
        
    signin_user($conn, $adminName, $pass);

}
else{
    header("location: AdminSignin.php");
    exit();
}

?>