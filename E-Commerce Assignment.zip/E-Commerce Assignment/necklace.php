<?php
session_start();
require_once("dbcontroller.php");
 include 'header.php';
 include 'navigation.php';

$db_handle = new DBController();
//Get method for adding/remove item to Cart
if(!empty($_GET["action"])) {
switch($_GET["action"]) {
	case "add":
		if(!empty($_POST["quantity"])) {
			$productByCode = $db_handle->runQuery("SELECT * FROM necklace WHERE code='" . $_GET["code"] . "'");
			//get the first data only with index [0]
                        $itemArray = array($productByCode[0]["code"]=>array('name'=>$productByCode[0]["name"], 
                                     'code'=>$productByCode[0]["code"], 'quantity'=>$_POST["quantity"],
                                      'price'=>$productByCode[0]["price"], 'image'=>$productByCode[0]["image"]));
			
			if(!empty($_SESSION["cart_item"])) {
                                //checking new add item with currect Cart
				if(in_array($productByCode[0]["code"],array_keys($_SESSION["cart_item"]))) {
					foreach($_SESSION["cart_item"] as $k => $v) {
                                                        
							if($productByCode[0]["code"] == $k) {
                                                               //if the quantity  is empty, starting the quantity from Zero
								if(empty($_SESSION["cart_item"][$k]["quantity"])) {
									$_SESSION["cart_item"][$k]["quantity"] = 0;
								}
                                                                //if the item already in the Cart, add the quantity
								$_SESSION["cart_item"][$k]["quantity"] += $_POST["quantity"];
							}
					}
				} 
                                //if current item is not in the cart, add the item
                                else {
					$_SESSION["cart_item"] = array_merge($_SESSION["cart_item"],$itemArray);
				}
			} else {
                                //if the session is empty, start the new session.
				$_SESSION["cart_item"] = $itemArray;
			}
		}
	break;
}
}
?>
<HTML>
<BODY>
	<div id="Check-cart">
    	<!-- <a href="Cart.php" type="button" class="btn btn-info"><b>Check Cart</b></a> -->
    	<!-- open a new tab -->
    	<button id="Check-cart" class="btn btn-info" onclick=" window.open('Cart.php','_blank')"> Check Cart</button>
    </div>
<!-- Product Grid  -->
<div id="product-grid" >
	<!-- style="display: inline-flex;" -->
	<div class="txt-heading"><h2>Necklaces</h2></div>
	<?php
	$product_array = $db_handle->runQuery("SELECT * FROM necklace ORDER BY id ASC");
	if (!empty($product_array)) { 
		foreach($product_array as $key=>$value){
	?>
		<div class="product-item">
            <div class="col-lg-4 col-sm-6">
            	<div class="thumbnail">
					<form method="post" action="necklace.php?action=add&code=<?php echo $product_array[$key]["code"]; ?>">
					<div class="product-image"><img src="<?php echo $product_array[$key]["image"]; ?>" style="width:125px; height:125px;"></div>
					<div class="product-tile-footer">
					<div class="product-title"><?php echo $product_array[$key]["name"]; ?></div>
					<div class="product-price"><?php echo "$".$product_array[$key]["price"]; ?></div>
					<div class="cart-action"><input type="text" class="product-quantity" name="quantity" value="1" size="2" />
		                        <!-- Post method for adding to Cart  -->
		                        <input type="submit" value="Add to Cart" class="btn btn-success" /></div>
					</div>
					</form>
				</div>
			</div>
		</div>
	<?php
		}
	}
	?>
</div>
</BODY>
</HTML>