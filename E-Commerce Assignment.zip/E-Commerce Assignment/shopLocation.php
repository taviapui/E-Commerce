<!DOCTYPE html>
<html>
	<?php 
	   include 'header.php'; 
	?>
	
	<body>
		<style>
			.link: a:hover {
			    color: green;
			    text-decoration: none;
			}

			.point{
				cursor: pointer;
				}



		</style>
		
	<div class="row">
		<div class="navbar-wrapper">
            <?php 
                include 'navigation.php';
            ?>
		</div>
	</div>

	<div class="container">
	  <div class="row">
  	  	<h2 style="text-align:center; font-style: italic; text-decoration-line: underline;"><b>      W&G Physical shop - </b></h2>
  	  	<div class="col-lg-8 col-md-8 col-sm-8 col-xs-12">
			<a onclick=" window.open('https://www.google.com.my/maps/place/Sunway+University/@3.067083,101.6013517,17z/data=!4m5!3m4!1s0x31cc4c8f5912644b:0x77612fa0225cad69!8m2!3d3.0670776!4d101.6035404','_blank')">
          	<img src="image/shop.jpg" width="50%"/ class="point">
		</div>
		<div>
			<h3><a onclick=" window.open('https://www.google.com.my/maps/place/Sunway+University/@3.067083,101.6013517,17z/data=!4m5!3m4!1s0x31cc4c8f5912644b:0x77612fa0225cad69!8m2!3d3.0670776!4d101.6035404','_blank')" style="text-decoration-line: none; color: #5fbf5f;" class="point">Director You to our physical shop</a></h3>
	  	 </div>

	  <div class="row">
		<div class="col-lg-1 col-md-2 col-sm-2 col-xs-0">
		</div>
		<div class="col-lg-10 col-md-8 col-sm-8 col-xs-12">
			<h3 style="text-align:center; font-size: 22px; margin-top:5%;">If you interest to visit our physical shop, you may click the inage or the word. We are waiting for your comming. See ya!!! </h3>
		</div>
		<div class="col-lg-1 col-md-2 col-sm-2 col-xs-0">
		</div>
	  </div>

	</div>
	
	<br><br><br><br><br><br><br>
	<?php 
    include "footer.php";
    ?>
	
	</body>
</html>

	
