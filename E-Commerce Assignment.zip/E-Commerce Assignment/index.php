<!DOCTYPE html>
<html>
	<?php 
	   include 'header.php';
	?>

<body>
			
<!-- navigation bar -->		  
	<div class="row" style="margin-bottom: 10%;">
		<div class="navbar-wrapper" style="position: fixed; min-width: 102%; z-index: 9999;">
          <?php 
            include 'navigation.php';
          ?>
		</div>
	</div>
<!-- /navigation bar -->	

<!-- slides show -->
	<div class="row">
    	<?php 
	      include 'carousel.php';
    	?>
	</div>
	
<!-- slides show -->


<!-- Hot item -->
	<?php 
	   include 'hotItem.php';
	?>
<!-- Hot item  -->


<!-- Footer -->
	<?php 
	   include 'footer.php';
	?>
<!-- Footer -->

</body>
</html>