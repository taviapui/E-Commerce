<div class="row" style="margin-top:-20px; ">
    <div >
      <a href="#hotItem"><img src="image/Cimg4.jpg" class="image-panel"/></a>
      <a href="#hotItem" id="ShopPanel" type="button" class="btn btn-info"><b>Shop More</b></a>
    </div>
</div>
