<!DOCTYPE html>
<html>
	<?php 
	   include 'header.php';
	?>

<body>
			
<!-- navigation bar -->		  
	<div class="row" style="margin-bottom: 10%;">
		<div class="navbar-wrapper" style="position: fixed; min-width: 102%; z-index: 9999;">
          <?php 
            include 'navigation.php';
          ?>
		</div>
	</div>
<!-- /navigation bar -->	

<div style=" margin: 15%; text-align:center; ">
	<h1 style="font-size: 50px; font-weight:bold;">Logout Out</h1>
<p style="font-size: 20px; margin-top: 5%;">You're successful logout from your account</p><br>
<p style="font-size: 20px;">Welcome to login our website again.</p><br>
<p style="font-size: 20px;">Thank you so much !!!</p>
</div>

<!-- Footer -->
	<?php 
	   include 'footer.php';
	?>
<!-- Footer -->

</body>
</html>