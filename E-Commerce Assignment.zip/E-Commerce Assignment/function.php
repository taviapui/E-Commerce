<?php

function validate($data) {
    $data = trim($data);
    $data = stripslashes($data);
    $data = htmlspecialchars($data);
    return $data;
}

function empty_input($username, $email, $contactNumber, $age, $pass, $confPass) {
    $result;
    if(empty($username) || empty($email) || empty($contactNumber) || empty($age)  || empty($pass) ||  empty($confPass)) {
        $result = true;
    }
    else{
        $result = false;
    }
    return $result;
}

function error_username($username) {
    $result;
    if(!preg_match('/^[a-zA-Z0-9]*$/', $username)) {
        $result = true;
    }
    else{
        $result = false;
    }
    return $result;
}

function error_email($email) {
    $result;
    if(filter_var($email, FILTER_VALIDATE_EMAIL)) {
        $result = false;
    }
    else{
        $result = true;
    }
    return $result;
}

function error_contactNumber($contactNumber) {
    $result;
    if(!preg_match('/^\d{3}\-\d{8}$/', $contactNumber)) {
        $result = true;
    }
    else{
        $result = false;
    }
    return $result;
}

function error_age($age) {
    $result;
    if(!preg_match('/^[0-9]+$/', $age)) {
        $result = true;
    }
    else{
        $result = false;
    }
    return $result;
}

function longer_password($pass) {
    $result;
    if(!preg_match('/^[a-zA-Z0-9!@#$%]{6,}$/', $pass)) {
        $result = true;
    }
    else{
        $result = false;
    }
    return $result;
}

function password_match($pass, $confPass) {
    $result;
    if($pass === $confPass) {
        $result = false;
    }
    else{
        $result = true;
    }
    return $result;
}

function username_exists($conn, $username) {
    $sql = "SELECT * FROM users WHERE username = '$username';";
    $result = mysqli_query($conn, $sql);
    if (mysqli_num_rows($result) > 0) {
        $result = true;
    }
    else {
        $result = false;
    }
    return $result;   
}

function email_exists($conn, $email) {
    $sql = "SELECT * FROM users WHERE email = '$email';";
    $result = mysqli_query($conn, $sql);
    if (mysqli_num_rows($result) > 0) {
        $result = true;
    }
    else {
        $result = false;
    }
    return $result;   
}

function register_user($conn, $username, $email, $contactNumber, $age, $pass) {
    $pass = validate($pass);
    $pass = password_hash($pass, PASSWORD_DEFAULT);
    $sql = "INSERT INTO users (username, email, contactNumber, age, pass) VALUES ('$username', '$email', '$contactNumber', '$age', '$pass');";
    $result = mysqli_query($conn, $sql);
    if ($result) {
        header("location: signin.php?error=register_succeeded");
        exit();
    }
    else {
        header("location: register.php?error=register_failed");
        exit();
    }

}

function empty_signin($username, $pass) {
    $result;
    if(empty($username) || empty($pass)) {
        $result = true;
    }
    else{
        $result = false;
    }
    return $result;
}

function signin_user($conn, $username, $pass) {
    $pass = validate($pass);
    //$pass = password_hash($pass, PASSWORD_DEFAULT);
    $sql = "SELECT * FROM users WHERE username = '$username';";
    $result = mysqli_query($conn, $sql);
    if(mysqli_num_rows($result) === 1) {
        $row = mysqli_fetch_assoc($result);
        if ($row["username"] === $username && password_verify($pass, $row["pass"])) {
            session_start();
            $_SESSION["username"] = $row["username"];
            header("location: index.php");
            exit();
        }
        else {
            header("location: signin.php?error=login_error");
            exit();
        }
    }
    else {
        header("location: signin.php?error=login_error");
        exit();
    }
}

function destroy_session_and_data() {
    unset($_SESSION["username"]);
    $_SESSION = array();
    session_unset();
    setcookie(session_name(), '', time() - 2592000, '/');
    session_destroy();
}

?>